#!/usr/bin/env bash
export RUN_TIME_CONSUMING=0
#export NOTEBOOKS_EXCLUDE=("./notebooks/ConnectionModel.ipynb")